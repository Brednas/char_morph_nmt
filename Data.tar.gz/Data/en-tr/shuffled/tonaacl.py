import sys

data = []
for i, line in enumerate(sys.stdin):
    line = line.strip() + ' '
    if not line:
        break
    pairs = line.split(' ; ')
    al = []    
    for pair in pairs:
        if not pair:
            continue
        parts = pair.split()
        if len(parts) != 2:
            print('Line %d, found %d parts' % (i, len(parts)), file=sys.stderr)
            continue
        s, t = parts
        if s == '0' and t == '0':  # no need to convert 0-0 to naacl format
            continue
        al.append([s, t])
    print('\n'.join('%d %s %s' % (i, s, t) for s, t in al))

